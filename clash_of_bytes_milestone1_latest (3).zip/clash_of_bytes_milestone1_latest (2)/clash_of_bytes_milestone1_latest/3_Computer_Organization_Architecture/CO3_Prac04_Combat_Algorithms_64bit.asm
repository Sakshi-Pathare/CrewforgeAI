; ==============================================================================
; Subject: Computer Organization & Architecture
; Course Outcome: CO3 | Practical 04 / Task 3
; Topic: 64-bit Algorithmic Arithmetic & String Processing (NASM Syntax)
; Target Architecture: x86-64 (AMD64 / Intel 64)
; Application: "Clash of Bytes" Combat Damage Scaling & Log Processing Engine
; ==============================================================================

section .data
    ; Combat damage inputs for Shift-and-Add algorithmic multiplication
    base_strike_damage  dq 28              ; Multiplicand (Base strike damage)
    combo_scaling_factor dq 5              ; Multiplier (Combo chain multiplier)
    calculated_product  dq 0              ; Resulting burst damage
    
    ; Test string for 64-bit hardware string processing (repne scasb & search)
    combat_log_event    db "[COMBAT] BLAZE_WARRIOR HIT SHADOW_NINJA! CRITICAL HIT! COMBO X3! CRITICAL HIT!", 0
    token_to_search     db "CRITICAL", 0
    token_match_count   dq 0
    computed_str_len    dq 0

section .bss
    saved_rflags        resq 1             ; Stores hardware CPU flags (ZF, CF, SF, OF)

section .text
    global _start
    global shift_add_multiply
    global count_string_length
    global count_token_matches

_start:
    ; ==========================================================================
    ; PART 1: 64-BIT SHIFT-AND-ADD MULTIPLICATION ALGORITHM
    ; Implements hardware-level binary multiplication on CPU registers:
    ;   RAX = Accumulator (Product)
    ;   RDX = Multiplicand (Shifted Left: RDX << 1)
    ;   RBX = Multiplier   (Shifted Right: RBX >> 1)
    ; ==========================================================================
    mov rdx, [base_strike_damage]          ; Multiplicand in RDX
    mov rbx, [combo_scaling_factor]        ; Multiplier in RBX
    xor rax, rax                           ; Clear Accumulator (Product = 0)
    
    test rbx, rbx                          ; Check if multiplier is zero
    jz .mult_complete

.mult_loop:
    test rbx, 1                            ; Test Least Significant Bit (LSB) of multiplier
    jz .skip_addition                      ; If LSB is 0, skip addition step
    add rax, rdx                           ; If LSB is 1, Accumulator += Multiplicand

.skip_addition:
    shl rdx, 1                             ; Multiplicand <<= 1 (Shift left by 1 bit)
    shr rbx, 1                             ; Multiplier >>= 1   (Shift right by 1 bit)
    jnz .mult_loop                         ; If Multiplier != 0, continue loop

.mult_complete:
    mov [calculated_product], rax          ; Store computed scaled damage
    pushfq                                 ; Push 64-bit RFLAGS to stack
    pop qword [saved_rflags]               ; Capture hardware status flags

    ; ==========================================================================
    ; PART 2: 64-BIT HARDWARE STRING PROCESSING (repne scasb)
    ; Calculates string length using processor string scan instruction:
    ;   RDI = String pointer
    ;   AL  = 0 (Search for null-terminator byte)
    ;   RCX = -1 (Maximum scan boundary)
    ; ==========================================================================
    mov rdi, combat_log_event              ; Load string address into RDI
    xor al, al                             ; Target byte: null terminator (0x00)
    mov rcx, -1                            ; Initial counter: 0xFFFFFFFFFFFFFFFF
    cld                                    ; Clear direction flag (scan forward)
    repne scasb                            ; Scan bytes until byte == AL
    not rcx                                ; Invert bits of RCX
    dec rcx                                ; Length = (~RCX) - 1
    mov [computed_str_len], rcx            ; Store computed string length

    ; ==========================================================================
    ; PART 3: EXIT PROGRAM
    ; ==========================================================================
    mov rax, 60                            ; sys_exit opcode
    xor rdi, rdi                           ; Exit code 0
    syscall
