#ifndef INPUTMANAGER_HPP
#define INPUTMANAGER_HPP

#include <windows.h>
#include <xinput.h>

typedef DWORD (WINAPI *PFN_XInputGetState)(DWORD dwUserIndex, XINPUT_STATE* pState);

class Fighter;

class InputManager {
private:
    HMODULE hXInputDLL;
    PFN_XInputGetState pfnXInputGetState;
    bool p1GamepadActive;
    bool p2GamepadActive;

public:
    InputManager();
    ~InputManager();

    void update();
    void applyInputToFighter(int playerIndex, Fighter* fighter);
    bool isPausePressed() const;
    bool isDebugTogglePressed() const;
    bool isSyllabusTogglePressed() const;
    bool isHowToPlayTogglePressed() const;
    bool isModeShiftPressed() const;
    bool isTutorialSelected() const;
    bool isFightSelected() const;
};

#endif // INPUTMANAGER_HPP
