@echo off
cd /d "%~dp0"

echo =======================================================================
echo   CLASH OF BYTES : JAVA SWING ARENA LAUNCHER (CO3 PRACTICAL)
echo =======================================================================
echo.

:: Auto-detect Java runtime
if exist "jdk\bin\java.exe" (
    set "JAVA_CMD=jdk\bin\java.exe"
) else if exist "..\retro_fighter_2d\jdk\bin\java.exe" (
    set "JAVA_CMD=..\retro_fighter_2d\jdk\bin\java.exe"
) else (
    set "JAVA_CMD=java"
)

if not exist "4_Object_Oriented_Programming_Java\bin\CO3\SwingGUI\GameLauncherGUI.class" (
    echo [*] GUI classes not compiled yet. Running build.bat first...
    call .\build.bat
)

echo [*] Launching Cyberpunk Swing GUI on Event Dispatch Thread...
start "" "%JAVA_CMD%" -cp 4_Object_Oriented_Programming_Java\bin CO3.SwingGUI.GameLauncherGUI
