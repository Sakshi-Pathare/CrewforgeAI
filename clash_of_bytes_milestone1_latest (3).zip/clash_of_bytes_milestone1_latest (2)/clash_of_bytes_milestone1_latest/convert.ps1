Add-Type -AssemblyName System.Drawing
$src = (Resolve-Path "screenshot_cg_task3.bmp").Path
$dest = "C:\Users\Varsharani\.gemini\antigravity-ide\brain\9faeabd5-fe31-4955-8f37-db4c7e2e0230\screenshot_cg_task3.png"
$img = [System.Drawing.Image]::FromFile($src)
$img.Save($dest, [System.Drawing.Imaging.ImageFormat]::Png)
$img.Dispose()
Write-Host "PNG saved successfully to $dest"
