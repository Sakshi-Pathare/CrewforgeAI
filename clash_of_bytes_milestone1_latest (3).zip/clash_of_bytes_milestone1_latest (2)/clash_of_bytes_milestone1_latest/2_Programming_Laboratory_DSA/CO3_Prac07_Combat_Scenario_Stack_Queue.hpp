#ifndef CO3_PRAC07_COMBAT_SCENARIO_STACK_QUEUE_HPP
#define CO3_PRAC07_COMBAT_SCENARIO_STACK_QUEUE_HPP

/*
 * Subject: Programming Laboratory (Data Structures & Algorithms)
 * Course Outcome: CO3 | Practical 07 / Task 3
 * Forwarding header to CO3_Combat_Action_Stack_Queue_Scenario.hpp
 */
#include "CO3_Combat_Action_Stack_Queue_Scenario.hpp"

#endif // CO3_PRAC07_COMBAT_SCENARIO_STACK_QUEUE_HPP
