/*
 * Subject: Programming Laboratory (Data Structures & Algorithms)
 * Course Outcomes: CO1, CO2, CO3 | Practicals 01 to 07 & Task 3
 * Topic: Comprehensive Test and Demonstration Driver for All DSA Practicals & Scenario Processing
 */

#include <iostream>
#include <iomanip>
#include "CO1_Prac01_1D_Arrays_Fighter_Move_Catalog.hpp"
#include "CO1_Prac02_2D_Sparse_Matrix_Fast_Transpose.hpp"
#include "CO2_Prac03_Singly_Linked_List_Particles.hpp"
#include "CO2_Prac04_Doubly_Linked_List_Match_Scores.hpp"
#include "CO2_Prac05_Circular_Linked_List_Arena_Buffs.hpp"
#include "CO3_Prac06_Stack_Combat_Formula_Evaluator.hpp"
#include "CO3_Combat_Action_Stack_Queue_Scenario.hpp"

void demonstratePrac01() {
    std::cout << "===================================================================\n";
    std::cout << " [PRACTICAL 01] 1D Arrays: Fighter Move Catalog CRUD\n";
    std::cout << " Course Outcome: CO1 | Concept: Insert, Read, Update, Delete in 1D Array\n";
    std::cout << "===================================================================\n";
    MoveCatalog catalog;
    std::cout << "  Pre-populated moves count: " << catalog.getMoveCount() << "\n";
    
    // Create / Insert
    catalog.insertMove(5, "Dragon Upper", 22, 5, 10);
    std::cout << "  [INSERT] Added Move ID 5 (Dragon Upper, DMG: 22)\n";

    // Read
    const MoveData* m = catalog.getMove(5);
    if (m) {
        std::cout << "  [READ] Move Found: " << m->name << " | Dmg: " << m->damage 
                  << " | Startup: " << m->startupFrames << " frames\n";
    }

    // Update
    catalog.updateMoveDamage(5, 26);
    std::cout << "  [UPDATE] Buffed Move ID 5 damage to: " << catalog.getMove(5)->damage << "\n";

    // Delete
    catalog.deleteMove(1);
    std::cout << "  [DELETE] Deleted Move ID 1. Total moves remaining: " << catalog.getMoveCount() << "\n\n";
}

void demonstratePrac02() {
    std::cout << "===================================================================\n";
    std::cout << " [PRACTICAL 02] 2D Arrays: Sparse Matrix Arena Grid & Fast Transpose\n";
    std::cout << " Course Outcome: CO1 | Concept: 3-Tuple Representation & O(cols+terms) Transpose\n";
    std::cout << "===================================================================\n";
    SparseArenaGrid grid;
    std::cout << "  Original Sparse Grid non-zero elements: " << grid.getTileCount() << "\n";
    std::cout << "  Sample original tiles (Row, Col, Type):\n";
    for (int i = 0; i < 3 && i < grid.getTileCount(); i++) {
        const SparseTile& t = grid.getTile(i);
        std::cout << "    [" << i << "] Row: " << t.row << ", Col: " << t.col << ", Type: " << t.tileType << "\n";
    }

    SparseArenaGrid transposed = grid.fastTranspose();
    std::cout << "  Fast Transpose Computed! Transposed tiles count: " << transposed.getTileCount() << "\n";
    std::cout << "  Sample transposed tiles (Row, Col, Type):\n";
    for (int i = 0; i < 3 && i < transposed.getTileCount(); i++) {
        const SparseTile& t = transposed.getTile(i);
        std::cout << "    [" << i << "] Row: " << t.row << ", Col: " << t.col << ", Type: " << t.tileType << "\n";
    }
    std::cout << "\n";
}

void demonstratePrac03() {
    std::cout << "===================================================================\n";
    std::cout << " [PRACTICAL 03] Singly Linked List: Dynamic Particle Node Management\n";
    std::cout << " Course Outcome: CO2 | Concept: Node Insertion, Traversal, and removeIf\n";
    std::cout << "===================================================================\n";
    struct TestParticle {
        int id;
        float lifetime;
    };

    SinglyLinkedList<TestParticle> list;
    list.insertFront({1, 0.5f});
    list.insertFront({2, 0.0f}); // Expired
    list.insertFront({3, 0.8f});
    list.insertFront({4, 0.0f}); // Expired
    list.insertFront({5, 1.2f});

    std::cout << "  Initial particle nodes in list: " << list.size() << "\n";

    // Deletion using lambda predicate (expired particles)
    list.removeIf([](const TestParticle& p) {
        return p.lifetime <= 0.0f;
    });

    std::cout << "  Active particles after removeIf (lifetime > 0): " << list.size() << "\n";
    std::cout << "  Surviving particle IDs: ";
    list.forEach([](const TestParticle& p) {
        std::cout << "#" << p.id << " (life: " << p.lifetime << "s) ";
    });
    std::cout << "\n\n";
}

void demonstratePrac04() {
    std::cout << "===================================================================\n";
    std::cout << " [PRACTICAL 04] Doubly Linked List: Sort & Linear O(N1 + N2) Merge\n";
    std::cout << " Course Outcome: CO2 | Concept: Doubly Linked Node Sorting & Merging\n";
    std::cout << "===================================================================\n";
    DoublyLinkedList poolA;
    poolA.insertEnd({"Blaze Warrior", 85, 8, 2});
    poolA.insertEnd({"Shadow Ninja", 110, 11, 3});
    poolA.insertEnd({"Cyber Brawler", 65, 5, 1});

    std::cout << "  Sorting Pool A by damage dealt (descending)...\n";
    poolA.sortDescending();
    for (DNode* c = poolA.getHead(); c != nullptr; c = c->next) {
        std::cout << "    Fighter: " << std::left << std::setw(16) << c->data.fighterName 
                  << " | Damage: " << c->data.damageDealt << "\n";
    }

    DoublyLinkedList poolB;
    poolB.insertEnd({"Valkyrie", 95, 9, 2});
    poolB.insertEnd({"Iron Golem", 70, 6, 1});
    poolB.sortDescending();

    std::cout << "  Merging Pool A & Pool B using O(N1 + N2) Linear Merge...\n";
    DoublyLinkedList merged = DoublyLinkedList::mergeSortedDescending(poolA, poolB);
    for (DNode* c = merged.getHead(); c != nullptr; c = c->next) {
        std::cout << "    [MERGED] " << std::left << std::setw(16) << c->data.fighterName 
                  << " | Damage: " << c->data.damageDealt << "\n";
    }
    std::cout << "\n";
}

void demonstratePrac05() {
    std::cout << "===================================================================\n";
    std::cout << " [PRACTICAL 05] Circular Linked List: Arena Power-Up & Buff Queue\n";
    std::cout << " Course Outcome: CO2 | Concept: Circular Node Insertion, Consumption, & Rotation\n";
    std::cout << "===================================================================\n";
    CircularBuffQueue buffQueue(4); // Max 4 buff slots in arena

    buffQueue.enqueueBuff(1, "Dragon's Might", "Blaze Warrior", 0.25f, 10.0f, "ATTACK_BOOST");
    buffQueue.enqueueBuff(2, "Shadow Haste", "Shadow Ninja", 0.20f, 8.0f, "SPEED_HASTE");
    buffQueue.enqueueBuff(3, "Titan Aegis", "Blaze Warrior", 0.30f, 12.0f, "SHIELD_FORTIFY");
    buffQueue.enqueueBuff(4, "Overdrive Surge", "Shadow Ninja", 0.35f, 6.0f, "RAGE_BURST");

    // Attempting to exceed max capacity (rejects)
    buffQueue.enqueueBuff(5, "Berserk Aura", "Blaze Warrior", 0.40f, 5.0f, "ATTACK_BOOST");

    std::cout << "\nActive Arena Buffs in Circular Queue:\n";
    buffQueue.displayActiveBuffs();

    std::cout << "\nConsuming Front Buff (FCFS Combat Activation):\n";
    CombatBuff consumed;
    buffQueue.consumeBuff(consumed);

    std::cout << "\nRotating Active Buff Wheel (Circular traversal):\n";
    buffQueue.rotateBuffWheel();
    buffQueue.displayActiveBuffs();
    std::cout << "\n";
}

void demonstratePrac06() {
    std::cout << "===================================================================\n";
    std::cout << " [PRACTICAL 06] Stack Operations: Real-Time Combat Formula Engine\n";
    std::cout << " Course Outcome: CO3 | Concept: Prefix->Infix, Infix->Postfix, & Damage Evaluation\n";
    std::cout << "===================================================================\n";

    std::string prefixFormula = "* + ATK RAGE / COMBO 2";
    std::cout << "  Input Battle Formula (Prefix): " << prefixFormula << "\n";

    std::string infixFormula = CombatFormulaStackEngine::prefixToInfix(prefixFormula);
    std::cout << "  a) Prefix to Infix (Display) : " << infixFormula << "\n";

    std::string postfixFormula = CombatFormulaStackEngine::infixToPostfix(infixFormula);
    std::cout << "  b) Infix to Postfix (Stack)  : " << postfixFormula << "\n";

    double atk = 24.0, rage = 6.0, combo = 4.0, def = 2.0;
    std::cout << "  Fighter Combat Stats Loaded  : ATK=" << atk << ", RAGE=" << rage 
              << ", COMBO=" << combo << ", DEF=" << def << "\n";

    std::string outInfix, outPostfix;
    double damage = CombatFormulaStackEngine::calculateCombatDamage(
        prefixFormula, atk, rage, combo, def, outInfix, outPostfix);

    std::cout << "  c) Evaluated Combat Damage   : " << damage << " HP (Formula: (24 + 6) * (4 / 2))\n\n";
}

void demonstrateTask03_ScenarioProcessing() {
    CombatScenarioEngine::runAll();
}

int main() {
    std::cout << "\n===================================================================\n";
    std::cout << "   PROGRAMMING LABORATORY (DSA) - PRACTICALS 01 TO 07 DRIVER\n";
    std::cout << "   Course Code: 2310214L | All Practicals & Task 3 Suite\n";
    std::cout << "===================================================================\n\n";

    demonstratePrac01();
    demonstratePrac02();
    demonstratePrac03();
    demonstratePrac04();
    demonstratePrac05();
    demonstratePrac06();
    demonstrateTask03_ScenarioProcessing();

    std::cout << "===================================================================\n";
    std::cout << "   ALL DSA PRACTICALS & TASK 3 COMPLETED SUCCESSFULLY!\n";
    std::cout << "===================================================================\n\n";
    return 0;
}
