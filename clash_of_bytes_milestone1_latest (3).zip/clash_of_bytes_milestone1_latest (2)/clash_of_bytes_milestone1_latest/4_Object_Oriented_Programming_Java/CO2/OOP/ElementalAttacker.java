package CO2.OOP;

/*
 * Subject: Problem Solving Using OOP (Java)
 * Course Outcome: CO4 | Practical 04
 * Topic: Interface Contract 2 for Multiple & Hybrid Inheritance (Elemental Offense)
 */
public interface ElementalAttacker {
    double castElementalStrike(String element, double baseAttack);
    String getElementalAffinity();
}
