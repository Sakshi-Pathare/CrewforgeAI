package CO2.OOP;

/*
 * Subject: Problem Solving Using OOP (Java)
 * Course Outcome: CO4 | Practical 04
 * Topic: Interface Contract 1 for Multiple & Hybrid Inheritance (Defensive Shielding)
 */
public interface ShieldBearer {
    double blockIncomingDamage(double incomingDamage);
    void deployAegisBarrier();
}
